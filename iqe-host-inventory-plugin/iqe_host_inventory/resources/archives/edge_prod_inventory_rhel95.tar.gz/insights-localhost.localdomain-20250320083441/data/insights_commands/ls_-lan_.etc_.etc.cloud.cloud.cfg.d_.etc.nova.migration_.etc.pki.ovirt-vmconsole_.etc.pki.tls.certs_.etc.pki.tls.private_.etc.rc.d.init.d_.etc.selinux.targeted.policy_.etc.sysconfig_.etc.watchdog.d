/bin/ls: cannot access '/etc/cloud/cloud.cfg.d': No such file or directory
/bin/ls: cannot access '/etc/nova/migration': No such file or directory
/bin/ls: cannot access '/etc/pki/ovirt-vmconsole': No such file or directory
/bin/ls: cannot access '/etc/watchdog.d/': No such file or directory
/etc:
total 1044
drwxr-xr-x. 85 0   0   8192 Mar 20 08:26 .
drwxr-xr-x. 12 0   0   4096 Mar 20 08:25 ..
-rw-------.  1 0   0      0 Mar 20 08:26 .pwd.lock
-rw-r--r--.  1 0   0      0 Mar 20 08:26 .rpm-ostree-shadow-mode-fixed2.stamp
-rw-r--r--.  1 0   0    190 Dec 31  1969 .updated
-rw-r--r--.  1 0   0   4673 Mar 20 08:25 DIR_COLORS
-rw-r--r--.  1 0   0   4755 Mar 20 08:25 DIR_COLORS.lightbgcolor
-rw-r--r--.  1 0   0     94 Mar 20 08:25 GREP_COLORS
drwxr-xr-x.  7 0   0    134 Mar 20 08:25 NetworkManager
drwxr-xr-x.  5 0   0     51 Mar 20 08:25 X11
-rw-r--r--.  1 0   0     12 Mar 20 08:25 adjtime
-rw-r--r--.  1 0   0   1529 Mar 20 08:25 aliases
drwxr-xr-x.  2 0   0   4096 Mar 20 08:25 alternatives
drwxr-xr-x.  2 0   0     83 Mar 20 08:25 alternatives-admindir
drwxr-xr-x.  3 0   0     51 Mar 20 08:25 ansible
drwxr-x---.  4 0   0    100 Mar 20 08:26 audit
drwxr-xr-x.  2 0   0     30 Mar 20 08:25 bash_completion.d
-rw-r--r--.  1 0   0   2658 Mar 20 08:25 bashrc
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 binfmt.d
-rw-r--r--.  1 0   0   1369 Mar 20 08:25 chrony.conf
-rw-r-----.  1 0 994    540 Mar 20 08:25 chrony.keys
drwxr-xr-x.  8 0   0    170 Mar 20 08:34 containers
drwxr-xr-x.  6 0   0     81 Mar 20 08:25 crypto-policies
-rw-------.  1 0   0      0 Mar 20 08:25 crypttab
-rw-r--r--.  1 0   0   1401 Mar 20 08:25 csh.cshrc
-rw-r--r--.  1 0   0   1112 Mar 20 08:25 csh.login
drwxr-xr-x.  4 0   0     78 Mar 20 08:25 dbus-1
drwxr-xr-x.  2 0   0     33 Mar 20 08:25 default
drwxr-xr-x.  2 0   0     23 Mar 20 08:25 depmod.d
drwxr-xr-x.  3 0   0     24 Mar 20 08:25 dhcp
drwxr-xr-x.  8 0   0    128 Mar 20 08:25 dnf
-rw-r--r--.  1 0 993  27839 Mar 20 08:25 dnsmasq.conf
drwxr-xr-x.  2 0 993      6 Mar 20 08:25 dnsmasq.d
-rw-r--r--.  1 0   0    117 Mar 20 08:25 dracut.conf
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 dracut.conf.d
-rw-r--r--.  1 0   0      0 Mar 20 08:25 environment
-rw-r--r--.  1 0   0   1362 Mar 20 08:25 ethertypes
-rw-r--r--.  1 0   0      0 Mar 20 08:25 exports
-rw-r--r--.  1 0   0     66 Mar 20 08:25 filesystems
drwxr-x---.  8 0   0    149 Mar 20 08:25 firewalld
-rw-r--r--.  1 0   0    615 Mar 20 08:25 fstab
-rw-r--r--.  1 0   0     38 Mar 20 08:25 fuse.conf
drwxr-xr-x.  4 0   0     64 Mar 20 08:25 fwupd
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 gcrypt
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 gnupg
drwxr-xr-x.  5 0   0     69 Mar 20 08:25 greenboot
-rw-r--r--.  1 0   0     62 Mar 20 08:26 group
-rw-r--r--.  1 0   0     51 Mar 20 08:26 group-
drwx------.  2 0   0   4096 Mar 20 08:25 grub.d
lrwxrwxrwx.  1 0   0     22 Mar 20 08:25 grub2-efi.cfg -> ../boot/grub2/grub.cfg
lrwxrwxrwx.  1 0   0     22 Mar 20 08:25 grub2.cfg -> ../boot/grub2/grub.cfg
----------.  1 0   0    415 Mar 20 08:26 gshadow
----------.  1 0   0    406 Mar 20 08:26 gshadow-
drwxr-xr-x.  3 0   0     20 Mar 20 08:25 gss
-rw-r--r--.  1 0   0      9 Mar 20 08:25 host.conf
-rw-r--r--.  1 0   0      1 Mar 20 08:26 hostname
-rw-r--r--.  1 0   0    158 Mar 20 08:25 hosts
-rw-r--r--.  1 0   0    490 Mar 20 08:25 inittab
-rw-r--r--.  1 0   0    943 Mar 20 08:25 inputrc
drwxr-xr-x.  2 0   0   4096 Mar 20 08:34 insights-client
drwxr-xr-x.  2 0   0    159 Mar 20 08:25 iproute2
-rw-r--r--.  1 0   0     23 Mar 20 08:25 issue
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 issue.d
-rw-r--r--.  1 0   0     22 Mar 20 08:25 issue.net
drwxr-xr-x.  3 0   0     38 Mar 20 08:25 kernel
drwxr-xr-x.  3 0   0     17 Mar 20 08:25 keys
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 keyutils
-rw-r--r--.  1 0   0    880 Mar 20 08:25 krb5.conf
drwxr-xr-x.  2 0   0     29 Mar 20 08:25 krb5.conf.d
-rw-r--r--.  1 0   0  13715 Mar 20 08:26 ld.so.cache
-rw-r--r--.  1 0   0     28 Mar 20 08:25 ld.so.conf
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 ld.so.conf.d
-rw-r-----.  1 0   0    191 Mar 20 08:25 libaudit.conf
drwxr-xr-x.  3 0   0     20 Mar 20 08:25 libblockdev
drwxr-xr-x.  2 0   0     35 Mar 20 08:25 libnl
drwxr-xr-x.  6 0   0     70 Mar 20 08:25 libreport
drwxr-xr-x.  2 0   0     62 Mar 20 08:25 libssh
-rw-r--r--.  1 0   0   2391 Mar 20 08:25 libuser.conf
-rw-r--r--.  1 0   0     13 Mar 20 08:25 locale.conf
lrwxrwxrwx.  1 0   0     38 Mar 20 08:25 localtime -> ../usr/share/zoneinfo/America/New_York
-rw-r--r--.  1 0   0   7779 Mar 20 08:25 login.defs
drwxr-xr-x.  2 0   0    121 Mar 20 08:25 logrotate.d
drwxr-xr-x.  7 0   0    115 Mar 20 08:25 lvm
-rw-r--r--.  1 0   0     33 Mar 20 08:26 machine-id
-rw-r--r--.  1 0   0    111 Mar 20 08:25 magic
drwxr-xr-x.  3 0   0     32 Mar 20 08:25 microcode_ctl
-rw-r--r--.  1 0   0   1208 Mar 20 08:25 mke2fs.conf
drwxr-xr-x.  2 0   0     36 Mar 20 08:25 modprobe.d
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 modules-load.d
-rw-r--r--.  1 0   0      0 Mar 20 08:25 motd
drwxr-xr-x.  2 0   0     29 Mar 20 08:25 motd.d
lrwxrwxrwx.  1 0   0     19 Mar 20 08:26 mtab -> ../proc/self/mounts
-rw-r--r--.  1 0   0     58 Mar 20 08:25 networks
drwx------.  3 0   0     66 Mar 20 08:25 nftables
-rw-r--r--.  1 0   0   2133 Mar 20 08:25 nsswitch.conf
-rw-r--r--.  1 0   0   2108 Mar 20 08:25 nsswitch.conf.bak
drwxr-xr-x.  2 0   0     35 Mar 20 08:25 nvme
drwxr-xr-x.  3 0   0     36 Mar 20 08:25 openldap
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 opt
lrwxrwxrwx.  1 0   0     21 Mar 20 08:25 os-release -> ../usr/lib/os-release
drwxr-xr-x.  3 0   0     23 Mar 20 08:25 ostree
drwxr-xr-x.  2 0   0   4096 Mar 20 08:25 pam.d
-rw-r--r--.  1 0   0     83 Mar 20 08:26 passwd
-rw-r--r--.  1 0   0     32 Mar 20 08:25 passwd-
drwxr-xr-x.  3 0   0     21 Mar 20 08:25 pkcs11
drwxr-xr-x.  3 0   0     27 Mar 20 08:25 pkgconfig
drwxr-xr-x. 14 0   0   4096 Mar 20 08:28 pki
drwxr-xr-x.  5 0   0     52 Mar 20 08:25 pm
drwxr-xr-x.  5 0   0     72 Mar 20 08:25 polkit-1
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 popt.d
-rw-r--r--.  1 0   0    233 Mar 20 08:25 printcap
-rw-r--r--.  1 0   0   1899 Mar 20 08:25 profile
drwxr-xr-x.  2 0   0   4096 Mar 20 08:25 profile.d
-rw-r--r--.  1 0   0   6568 Mar 20 08:25 protocols
drwxr-xr-x.  3 0   0     36 Mar 20 08:25 rc.d
lrwxrwxrwx.  1 0   0     13 Mar 20 08:25 rc.local -> rc.d/rc.local
-rw-r--r--.  1 0   0     44 Mar 20 08:25 redhat-release
-rw-r--r--.  1 0   0   1787 Mar 20 08:25 request-key.conf
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 request-key.d
-rw-r--r--.  1 0   0     55 Mar 20 08:26 resolv.conf
drwxr-xr-x.  3 0   0     40 Mar 20 08:25 rhc
drwxr-xr-x.  6 0   0     84 Mar 20 08:25 rhsm
-rw-r--r--.  1 0   0   1634 Mar 20 08:25 rpc
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 rpm
-rw-r--r--.  1 0   0    246 Mar 20 08:25 rpm-ostreed.conf
-rw-r--r--.  1 0   0    458 Mar 20 08:25 rsyncd.conf
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 rwtab.d
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 sasl2
drwxr-xr-x.  7 0   0   4096 Mar 20 08:25 security
drwxr-xr-x.  3 0   0     57 Mar 20 08:25 selinux
-rw-r--r--.  1 0   0 692252 Mar 20 08:25 services
-rw-r--r--.  1 0   0    216 Mar 20 08:25 sestatus.conf
----------.  1 0   0    449 Mar 20 08:26 shadow
----------.  1 0   0    454 Mar 20 08:26 shadow-
-rw-r--r--.  1 0   0     68 Mar 20 08:25 shells
drwxr-xr-x.  2 0   0     62 Mar 20 08:25 skel
drwxr-xr-x.  6 0   0     86 Mar 20 08:25 sos
drwxr-xr-x.  4 0   0   4096 Mar 20 08:26 ssh
drwxr-xr-x.  2 0   0     77 Mar 20 08:25 ssl
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 statetab.d
-rw-r--r--.  1 0   0     24 Mar 20 08:26 subgid
-rw-r--r--.  1 0   0      0 Mar 20 08:25 subgid-
-rw-r--r--.  1 0   0     24 Mar 20 08:26 subuid
-rw-r--r--.  1 0   0      0 Mar 20 08:25 subuid-
-rw-r-----.  1 0   0   3181 Mar 20 08:25 sudo-ldap.conf
-rw-r-----.  1 0   0   3983 Mar 20 08:25 sudo.conf
-r--r-----.  1 0   0   4328 Mar 20 08:25 sudoers
drwxr-x---.  2 0   0     20 Mar 20 08:26 sudoers.d
drwxr-xr-x.  3 0   0     24 Mar 20 08:25 swid
drwxr-xr-x.  3 0   0    178 Mar 20 08:25 sysconfig
-rw-r--r--.  1 0   0    449 Mar 20 08:25 sysctl.conf
drwxr-xr-x.  2 0   0     28 Mar 20 08:25 sysctl.d
lrwxrwxrwx.  1 0   0     14 Mar 20 08:25 system-release -> redhat-release
-rw-r--r--.  1 0   0     41 Mar 20 08:25 system-release-cpe
drwxr-xr-x.  4 0   0    166 Mar 20 08:25 systemd
drwxr-xr-x.  2 0   0      6 Mar 20 08:25 terminfo
drwxr-xr-x.  2 0   0     22 Mar 20 08:25 tmpfiles.d
drwxr-xr-x.  3 0   0     51 Mar 20 08:25 tpm2-tss
drwxr-xr-x.  4 0   0     68 Mar 20 08:26 udev
drwxr-xr-x.  2 0   0     60 Mar 20 08:25 udisks2
drwxr-xr-x.  4 0   0     93 Mar 20 08:25 usbguard
-rw-r--r--.  1 0   0   1184 Mar 20 08:25 virc
drwxr-xr-x.  2 0   0     33 Mar 20 08:25 wpa_supplicant
-rw-r--r--.  1 0   0    817 Mar 20 08:25 xattr.conf
drwxr-xr-x.  4 0   0     38 Mar 20 08:25 xdg
drwxr-xr-x.  2 0   0     25 Mar 20 08:34 yum.repos.d

/etc/pki/tls/certs:
total 0
drwxr-xr-x. 2 0 0  54 Mar 20 08:25 .
drwxr-xr-x. 6 0 0 143 Mar 20 08:25 ..
lrwxrwxrwx. 1 0 0  49 Mar 20 08:25 ca-bundle.crt -> /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem
lrwxrwxrwx. 1 0 0  55 Mar 20 08:25 ca-bundle.trust.crt -> /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt

/etc/pki/tls/private:
total 0
drwxr-xr-x. 2 0 0   6 Mar 20 08:25 .
drwxr-xr-x. 6 0 0 143 Mar 20 08:25 ..

/etc/rc.d/init.d:
total 4
drwxr-xr-x. 2 0 0   20 Mar 20 08:25 .
drwxr-xr-x. 3 0 0   36 Mar 20 08:25 ..
-rw-r--r--. 1 0 0 1161 Mar 20 08:25 README

/etc/selinux/targeted/policy:
total 3480
drwxr-xr-x. 2 0 0      23 Mar 20 08:25 .
drwxr-xr-x. 6 0 0     147 Mar 20 08:25 ..
-rw-r--r--. 1 0 0 3560361 Mar 20 08:25 policy.33

/etc/sysconfig:
total 44
drwxr-xr-x.  3 0 0  178 Mar 20 08:25 .
drwxr-xr-x. 85 0 0 8192 Mar 20 08:26 ..
-rw-r--r--.  1 0 0   50 Mar 20 08:25 chronyd
-rw-r--r--.  1 0 0   73 Mar 20 08:25 firewalld
-rw-r--r--.  1 0 0   39 Mar 20 08:25 kernel
-rw-r--r--.  1 0 0   30 Mar 20 08:25 network
drwxr-xr-x.  2 0 0   33 Mar 20 08:25 network-scripts
-rw-------.  1 0 0  364 Mar 20 08:25 nftables.conf
-rw-r--r--.  1 0 0 2915 Mar 20 08:25 raid-check
lrwxrwxrwx.  1 0 0   17 Mar 20 08:25 selinux -> ../selinux/config
-rw-r-----.  1 0 0  384 Mar 20 08:25 sshd
-rw-r--r--.  1 0 0  258 Mar 20 08:25 wpa_supplicant