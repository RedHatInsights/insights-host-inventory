total 0
drwxr-xr-x. 3 0 0    0 Jul 28 13:58 .
drwxr-xr-x. 4 0 0    0 Jul 28 13:58 ..
drwxr-xr-x. 2 0 0    0 Jul 28 13:59 power
lrwxrwxrwx. 1 0 0    0 Jul 28 13:58 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Jul 28 13:58 uevent