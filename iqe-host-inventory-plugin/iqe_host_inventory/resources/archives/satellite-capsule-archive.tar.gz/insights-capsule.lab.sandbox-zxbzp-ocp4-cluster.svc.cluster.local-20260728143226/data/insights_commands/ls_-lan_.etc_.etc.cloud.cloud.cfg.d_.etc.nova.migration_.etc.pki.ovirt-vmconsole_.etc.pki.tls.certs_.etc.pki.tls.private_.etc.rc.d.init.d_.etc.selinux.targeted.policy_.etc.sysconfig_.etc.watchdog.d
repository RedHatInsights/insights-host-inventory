/bin/ls: cannot access '/etc/nova/migration': No such file or directory
/bin/ls: cannot access '/etc/pki/ovirt-vmconsole': No such file or directory
/bin/ls: cannot access '/etc/watchdog.d/': No such file or directory
/etc:
total 1168
drwxr-xr-x. 107   0   0   8192 Jul 28 14:14 .
dr-xr-xr-x.  19   0   0    246 Jul 28 13:59 ..
-rw-------.   1   0   0      0 Apr 23  2025 .pwd.lock
-rw-r--r--.   1   0   0    208 Apr 23  2025 .updated
-rw-r--r--.   1   0   0   4673 Dec  9  2024 DIR_COLORS
-rw-r--r--.   1   0   0   4755 Dec  9  2024 DIR_COLORS.lightbgcolor
-rw-r--r--.   1   0   0     94 Aug  9  2021 GREP_COLORS
drwxr-xr-x.   7   0   0    134 Apr 23  2025 NetworkManager
drwxr-xr-x.   2   0   0     48 Apr 23  2025 PackageKit
drwxr-xr-x.   5   0   0     51 Apr 23  2025 X11
-rw-r--r--.   1   0   0     12 Jan 16  2025 adjtime
-rw-r--r--.   1   0   0   1529 Jun 23  2020 aliases
drwxr-xr-x.   2   0   0   4096 Apr 23  2025 alternatives
-rw-r--r--.   1   0   0    541 Dec 11  2024 anacrontab
drwxr-xr-x.   3   0   0     51 Jul 28 14:12 ansible
drwxr-x---.   4   0   0    100 Apr 23  2025 audit
drwxr-xr-x.   3   0   0     46 Apr 23  2025 authselect
drwxr-xr-x.   2   0   0     88 Jul 28 14:12 bash_completion.d
-rw-r--r--.   1   0   0   2658 Feb  7  2024 bashrc
-rw-r--r--.   1   0   0    535 Jul 30  2024 bindresvport.blacklist
drwxr-xr-x.   2   0   0      6 Jan 28  2025 binfmt.d
-rw-r--r--.   1   0   0   1369 Nov 11  2024 chrony.conf
-rw-r-----.   1   0 995    540 Nov 11  2024 chrony.keys
drwxr-xr-x.   2   0   0     26 Apr 23  2025 cifs-utils
drwxr-xr-x.   4   0   0     59 Apr 23  2025 cloud
drwxr-xr-x.   4   0   0     66 Apr 23  2025 cockpit
drwxr-xr-x.   2   0   0     21 Apr 23  2025 cron.d
drwxr-xr-x.   2   0   0      6 Mar 23  2022 cron.daily
-rw-r--r--.   1   0   0      0 Dec 11  2024 cron.deny
drwxr-xr-x.   2   0   0     22 Mar 23  2022 cron.hourly
drwxr-xr-x.   2   0   0      6 Mar 23  2022 cron.monthly
drwxr-xr-x.   2   0   0      6 Mar 23  2022 cron.weekly
-rw-r--r--.   1   0   0    451 Mar 23  2022 crontab
drwxr-xr-x.   6   0   0     81 Apr 23  2025 crypto-policies
-rw-r--r--.   1   0   0   1401 Feb  7  2024 csh.cshrc
-rw-r--r--.   1   0   0   1112 Feb  7  2024 csh.login
drwxr-xr-x.   4   0   0     78 Apr 23  2025 dbus-1
drwxr-xr-x.   2   0   0     31 Apr 23  2025 debuginfod
drwxr-xr-x.   2   0   0     33 Apr 23  2025 default
drwxr-xr-x.   2   0   0     23 Apr 23  2025 depmod.d
drwxr-x---.   3   0   0     24 Apr 23  2025 dhcp
drwxr-xr-x.   8   0   0    128 Apr 23  2025 dnf
-rw-r--r--.   1   0   0    117 Mar 11  2025 dracut.conf
drwxr-xr-x.   2   0   0      6 Mar 11  2025 dracut.conf.d
-rw-r--r--.   1   0   0      0 Feb  7  2024 environment
-rw-r--r--.   1   0   0   1362 Jun 23  2020 ethertypes
-rw-r--r--.   1   0   0      0 Jun 23  2020 exports
drwxr-xr-x.   2   0   0      6 Feb 16  2025 exports.d
lrwxrwxrwx.   1   0   0     56 May 15  2023 favicon.png -> /usr/share/icons/hicolor/16x16/apps/fedora-logo-icon.png
-rw-r--r--.   1   0   0     66 Jun 23  2020 filesystems
drwxr-xr-x.   3   0   0     20 Apr 23  2025 fonts
drwxr-xr-x.   3   0   0     50 Jul 28 14:11 foreman-installer
drwxr-x---.   2   0   0     34 Jul 28 14:12 foreman-maintain
drwxr-xr-x.   3   0   0   4096 Jul 28 14:13 foreman-proxy
-rw-r--r--.   1   0   0    207 Apr 23  2025 fstab
drwxr-xr-x.   4   0   0     64 Apr 23  2025 fwupd
drwxr-xr-x.   2   0   0      6 Nov 25  2024 galaxy-importer
drwxr-xr-x.   2   0   0      6 Aug  1  2024 gcrypt
drwxr-xr-x.   2   0   0      6 Apr 26  2023 gnupg
drwxr-xr-x.   4   0   0     40 Apr 23  2025 groff
-rw-r--r--.   1   0   0    647 Jul 28 14:13 group
-rw-r--r--.   1   0   0    634 Jul 28 14:13 group-
drwx------.   2   0   0   4096 Jul 28 14:11 grub.d
lrwxrwxrwx.   1   0   0     22 Oct  8  2025 grub2-efi.cfg -> ../boot/grub2/grub.cfg
lrwxrwxrwx.   1   0   0     22 Oct  8  2025 grub2.cfg -> ../boot/grub2/grub.cfg
----------.   1   0   0    516 Jul 28 14:13 gshadow
----------.   1   0   0    506 Jul 28 14:13 gshadow-
drwxr-xr-x.   3   0   0     20 Apr 23  2025 gss
drwxr-xr-x.   2   0   0     79 Apr 23  2025 gssproxy
-rw-r--r--.   1   0   0      9 Jun 23  2020 host.conf
-rw-r--r--.   1   0   0      8 Jul 28 13:59 hostname
-rw-r--r--.   1   0   0    447 Jul 28 14:14 hosts
drwxr-xr-x.   5   0   0    105 Jul 28 14:11 httpd
-rw-r--r--.   1   0   0   5799 Feb 16  2025 idmapd.conf
-rw-r--r--.   1   0   0    490 Jan 28  2025 inittab
-rw-r--r--.   1   0   0    943 Jun 23  2020 inputrc
drwxr-xr-x.   2   0   0   4096 Jul 28 14:31 insights-client
-rw-r--r--.   1   0   0     23 Mar 17  2025 issue
drwxr-xr-x.   2   0   0     27 Apr 23  2025 issue.d
-rw-r--r--.   1   0   0     22 Mar 17  2025 issue.net
drwxr-xr-x.   4   0   0     33 Apr 23  2025 kdump
-rw-r--r--.   1   0   0   8979 Apr 23  2025 kdump.conf
drwxr-xr-x.   3   0   0     38 Apr 23  2025 kernel
drwxr-xr-x.   3   0   0     17 Apr 23  2025 keys
drwxr-xr-x.   2   0   0      6 Oct 17  2022 keyutils
-rw-r--r--.   1   0   0    880 Jan 29  2025 krb5.conf
drwxr-xr-x.   2   0   0     55 Apr 23  2025 krb5.conf.d
-rw-r--r--.   1   0   0  16087 Jul 28 14:13 ld.so.cache
-rw-r--r--.   1   0   0     28 Aug  2  2021 ld.so.conf
drwxr-xr-x.   2   0   0      6 Oct 10  2025 ld.so.conf.d
-rw-r-----.   1   0   0    191 Feb 12  2025 libaudit.conf
drwxr-xr-x.   2   0   0   4096 Apr 23  2025 libibverbs.d
drwxr-xr-x.   2   0   0     35 Apr 23  2025 libnl
drwxr-xr-x.   6   0   0     70 Apr 23  2025 libreport
drwxr-xr-x.   2   0   0     62 Apr 23  2025 libssh
-rw-r--r--.   1   0   0   2391 Mar  1  2021 libuser.conf
drwx------.   2   0   0     52 Jul 28 14:12 libvirt
-rw-r--r--.   1   0   0     13 Jul 28 13:59 locale.conf
lrwxrwxrwx.   1   0   0     38 Apr 23  2025 localtime -> ../usr/share/zoneinfo/America/New_York
-rw-r--r--.   1   0   0   7779 Nov  5  2024 login.defs
-rw-r--r--.   1   0   0    496 Jun  7  2020 logrotate.conf
drwxr-xr-x.   2   0   0   4096 Jul 28 14:13 logrotate.d
-r--r--r--.   1   0   0     33 Jul 28 13:59 machine-id
-rw-r--r--.   1   0   0    111 Nov 29  2023 magic
-rw-r--r--.   1   0   0    272 Apr 22  2020 mailcap
-rw-r--r--.   1   0   0   5122 Jan 16  2025 makedumpfile.conf.sample
-rw-r--r--.   1   0   0   5235 Sep 20  2022 man_db.conf
drwxr-xr-x.   3   0   0     32 Apr 23  2025 microcode_ctl
-rw-r--r--.   1   0   0  67454 Apr 22  2020 mime.types
-rw-r--r--.   1   0   0   1208 Jan 24  2025 mke2fs.conf
drwxr-xr-x.   2   0   0     42 Apr 23  2025 modprobe.d
drwxr-xr-x.   2   0   0      6 Jan 28  2025 modules-load.d
-rw-r--r--.   1   0   0      0 Jun 23  2020 motd
drwxr-xr-x.   2   0   0     21 Jul 28 14:31 motd.d
lrwxrwxrwx.   1   0   0     19 Apr 23  2025 mtab -> ../proc/self/mounts
-rw-r--r--.   1   0   0    767 Jul 30  2024 netconfig
-rw-r--r--.   1   0   0     58 Jun 23  2020 networks
-rw-r--r--.   1   0   0   1631 Feb 16  2025 nfs.conf
-rw-r--r--.   1   0   0   3604 Feb 16  2025 nfsmount.conf
drwx------.   3   0   0     66 Jul 28 14:12 nftables
-rw-r--r--.   1   0   0   2124 Apr 23  2025 nsswitch.conf
-rw-r--r--.   1   0   0   2108 Apr  8  2025 nsswitch.conf.bak
drwxr-xr-x.   2   0   0      6 Dec  9  2022 oddjob
-rw-r--r--.   1   0   0   4922 Dec  9  2022 oddjobd.conf
drwxr-xr-x.   2   0   0     70 Apr 23  2025 oddjobd.conf.d
drwxr-xr-x.   3   0   0     36 Apr 23  2025 openldap
drwxr-xr-x.   2   0   0      6 Jun 25  2024 opt
lrwxrwxrwx.   1   0   0     21 Mar 17  2025 os-release -> ../usr/lib/os-release
drwxr-xr-x.   2   0   0   4096 Jul 28 14:13 pam.d
-rw-r--r--.   1   0   0   1560 Jul 28 14:13 passwd
-rw-r--r--.   1   0   0   1493 Jul 28 14:13 passwd-
drwxr-xr-x.   3   0   0     21 Apr 23  2025 pkcs11
drwxr-xr-x.   3   0   0     27 Jul 28 14:12 pkgconfig
drwxr-xr-x.  16   0   0   4096 Jul 28 14:13 pki
drwxr-xr-x.   5   0   0     52 Apr 23  2025 pm
drwxr-xr-x.   5   0   0     72 Apr 23  2025 polkit-1
drwxr-xr-x.   2   0   0      6 Aug 10  2021 popt.d
drwxr-xr-x.   3   0   0     21 Jul 28 14:13 postgresql-setup
-rw-r--r--.   1   0   0    233 Jun 23  2020 printcap
-rw-r--r--.   1   0   0   1899 Feb  7  2024 profile
drwxr-xr-x.   2   0   0   4096 Jul 28 14:11 profile.d
-rw-r--r--.   1   0   0   6568 Jun 23  2020 protocols
drwxr-xr-x.   3   0   0     38 Jul 28 14:13 pulp
drwxr-xr-x.   5   0   0     49 Jul 28 14:11 puppetlabs
drwxr-xr-x.   3   0   0     50 Apr 23  2025 qemu-ga
drwxr-xr-x.   3   0   0     36 Apr 23  2025 rc.d
lrwxrwxrwx.   1   0   0     13 Jan 28  2025 rc.local -> rc.d/rc.local
-rw-r--r--.   1   0   0     44 Mar 17  2025 redhat-release
drwxr-xr-x.   2 992   0     70 Jul 28 14:13 redis
-rw-r--r--.   1   0   0   1787 Oct 17  2022 request-key.conf
drwxr-xr-x.   2   0   0     30 Apr 23  2025 request-key.d
-rw-r--r--.   1   0   0    216 Jul 28 13:59 resolv.conf
drwxr-xr-x.   3   0   0     40 Apr 23  2025 rhc
drwxr-xr-x.   6   0   0    112 Jul 28 14:10 rhsm
-rw-r--r--.   1   0   0   1634 Aug  1  2021 rpc
drwxr-xr-x.   2   0   0      6 Jan 13  2025 rpm
-rw-r--r--.   1   0   0    458 Feb  5  2025 rsyncd.conf
-rw-r--r--.   1   0   0   3380 Dec 17  2024 rsyslog.conf
drwxr-xr-x.   2   0   0     31 Apr 23  2025 rsyslog.d
drwxr-xr-x.   2   0   0     51 Apr 23  2025 rwtab.d
drwxr-xr-x.   2   0   0      6 Sep 12  2022 sasl2
drwxr-xr-x.   7   0   0   4096 Apr 23  2025 security
drwxr-xr-x.   3   0   0     57 Apr 23  2025 selinux
-rw-r--r--.   1   0   0 692252 Jun 23  2020 services
-rw-r--r--.   1   0   0    216 Feb 19  2024 sestatus.conf
drwxr-xr-x.   2   0   0     33 Apr 23  2025 setroubleshoot
----------.   1   0   0    753 Jul 28 14:13 shadow
----------.   1   0   0    732 Jul 28 14:13 shadow-
-rw-r--r--.   1   0   0     44 Jun 23  2020 shells
drwxr-xr-x.   2   0   0     62 Apr 23  2025 skel
drwxr-xr-x.   6   0   0     86 Apr 23  2025 sos
drwxr-xr-x.   4   0   0   4096 Jul 28 14:01 ssh
drwxr-xr-x.   2   0   0     77 Apr 23  2025 ssl
drwx------.   4 996 996     31 Apr 23  2025 sssd
drwxr-xr-x.   2   0   0      6 Jun 25  2024 statetab.d
-rw-r--r--.   1   0   0     24 Jul 28 13:59 subgid
-rw-r--r--.   1   0   0      0 Jun 23  2020 subgid-
-rw-r--r--.   1   0   0     24 Jul 28 13:59 subuid
-rw-r--r--.   1   0   0      0 Jun 23  2020 subuid-
-rw-r-----.   1   0   0   3181 Jan 24  2024 sudo-ldap.conf
-rw-r-----.   1   0   0   3983 Jan 24  2024 sudo.conf
-r--r-----.   1   0   0   4328 Jan 24  2024 sudoers
drwxr-x---.   2   0   0     33 Jul 28 13:59 sudoers.d
drwxr-xr-x.   3   0   0     24 Apr 23  2025 swid
drwxr-xr-x.   3   0   0   4096 Jul 28 14:12 sysconfig
-rw-r--r--.   1   0   0    449 Jan 28  2025 sysctl.conf
drwxr-xr-x.   2   0   0     28 Apr 23  2025 sysctl.d
lrwxrwxrwx.   1   0   0     14 Mar 17  2025 system-release -> redhat-release
-rw-r--r--.   1   0   0     41 Mar 17  2025 system-release-cpe
drwxr-xr-x.   4   0   0    166 Apr 23  2025 systemd
drwxr-xr-x.   2   0   0      6 Aug 21  2023 terminfo
drwxr-xr-x.   2   0   0     22 Apr 23  2025 tmpfiles.d
drwxr-xr-x.   3   0   0     51 Apr 23  2025 tpm2-tss
drwxr-xr-x.   3   0   0    160 Apr 23  2025 tuned
drwxr-xr-x.   4   0   0     68 Jul 28 13:59 udev
-rw-r--r--.   1   0   0   1184 Feb 26  2025 virc
-rw-r--r--.   1   0   0    817 Aug  9  2021 xattr.conf
drwxr-xr-x.   4   0   0     38 Apr 23  2025 xdg
drwxr-xr-x.   2   0   0     57 Apr 23  2025 yum
lrwxrwxrwx.   1   0   0     12 Feb  7  2025 yum.conf -> dnf/dnf.conf
drwxr-xr-x.   2   0   0     25 Jul 28 14:10 yum.repos.d

/etc/cloud/cloud.cfg.d:
total 8
drwxr-xr-x. 2 0 0   42 Apr 23  2025 .
drwxr-xr-x. 4 0 0   59 Apr 23  2025 ..
-rw-r--r--. 1 0 0 2071 Nov 25  2024 05_logging.cfg
-rw-r--r--. 1 0 0  167 Nov 25  2024 README

/etc/pki/tls/certs:
total 0
drwxr-xr-x. 2 0 0  54 Apr 23  2025 .
drwxr-xr-x. 6 0 0 143 Apr 23  2025 ..
lrwxrwxrwx. 1 0 0  49 Aug 19  2024 ca-bundle.crt -> /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem
lrwxrwxrwx. 1 0 0  55 Aug 19  2024 ca-bundle.trust.crt -> /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt

/etc/pki/tls/private:
total 0
drwxr-xr-x. 2 0 0   6 Jan 29  2025 .
drwxr-xr-x. 6 0 0 143 Apr 23  2025 ..

/etc/rc.d/init.d:
total 4
drwxr-xr-x. 2 0 0   20 Apr 23  2025 .
drwxr-xr-x. 3 0 0   36 Apr 23  2025 ..
-rw-r--r--. 1 0 0 1161 Jan 28  2025 README

/etc/selinux/targeted/policy:
total 3436
drwxr-xr-x. 2 0 0      23 Jul 28 14:14 .
drwxr-xr-x. 5 0 0     133 Jul 28 14:14 ..
-rw-r--r--. 1 0 0 3517575 Jul 28 14:14 policy.33

/etc/sysconfig:
total 80
drwxr-xr-x.   3 0 0 4096 Jul 28 14:12 .
drwxr-xr-x. 107 0 0 8192 Jul 28 14:14 ..
-rw-r--r--.   1 0 0   50 Nov 11  2024 chronyd
-rw-r--r--.   1 0 0  150 Apr  4  2025 cpupower
-rw-r--r--.   1 0 0  110 Dec 11  2024 crond
lrwxrwxrwx.   1 0 0   15 Oct  8  2025 grub -> ../default/grub
-rw-r--r--.   1 0 0  348 Aug 18  2025 htcacheclean
-rw-r--r--.   1 0 0 1400 Nov  6  2024 irqbalance
-rw-r--r--.   1 0 0 2673 Jan 16  2025 kdump
-rw-r--r--.   1 0 0   39 Apr 23  2025 kernel
-rw-r--r--.   1 0 0  310 Sep 20  2022 man-db
-rw-r--r--.   1 0 0   30 Apr 23  2025 network
drwxr-xr-x.   2 0 0   33 Apr 23  2025 network-scripts
-rw-------.   1 0 0  364 Oct 16  2025 nftables.conf
-rw-r--r--.   1 0 0   92 Jul 23  2024 puppet
-rw-r--r--.   1 0 0   87 Jul 17  2024 pxp-agent
-rw-r--r--.   1 0 0 1912 Apr  3  2025 qemu-ga
-rw-r--r--.   1 0 0   73 Feb 15  2024 rpcbind
-rw-r--r--.   1 0 0  196 Dec 17  2024 rsyslog
-rw-r--r--.   1 0 0    0 Mar 23  2022 run-parts
lrwxrwxrwx.   1 0 0   17 Apr 23  2025 selinux -> ../selinux/config
-rw-r-----.   1 0 0  384 Feb 18  2025 sshd