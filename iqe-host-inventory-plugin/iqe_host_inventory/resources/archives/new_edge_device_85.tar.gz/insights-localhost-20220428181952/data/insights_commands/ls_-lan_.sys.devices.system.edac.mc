total 0
drwxr-xr-x. 3 0 0    0 Apr 28 14:08 .
drwxr-xr-x. 4 0 0    0 Apr 28 14:08 ..
drwxr-xr-x. 2 0 0    0 Apr 28 14:09 power
lrwxrwxrwx. 1 0 0    0 Apr 28 14:08 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Apr 28 14:08 uevent
