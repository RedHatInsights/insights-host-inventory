total 0
drwxr-xr-x. 3 65534 65534    0 May 16 10:02 .
drwxr-xr-x. 4 65534 65534    0 May 16 10:02 ..
drwxr-xr-x. 2 65534 65534    0 May 16 10:02 power
lrwxrwxrwx. 1 65534 65534    0 May 16 10:02 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 65534 65534 4096 May 16 10:02 uevent
