/boot:
total 8
dr-xr-xr-x.  2 0 0 4096 Aug 12  2018 .
dr-xr-xr-x. 18 0 0 4096 May 16 10:01 ..
